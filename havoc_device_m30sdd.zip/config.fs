[system/product/vendor_overlay/*/bin/*]
mode: 0755
user: AID_ROOT
group: AID_SHELL
caps: 0

[product/vendor_overlay/*/bin/*]
mode: 0755
user: AID_ROOT
group: AID_SHELL
caps: 0

[metadata/]
mode: 0771
user: AID_ROOT
group: AID_SYSTEM
caps: 0

[efs/]
mode: 0771
user: AID_SYSTEM
group: AID_RADIO
caps: 0

[carrier/]
mode: 0771
user: AID_SYSTEM
group: AID_RADIO
caps: 0

[dqmdbg/]
mode: 0770
user: AID_SYSTEM
group: AID_SYSTEM
caps: 0

[spu/]
mode: 0770
user: AID_SYSTEM
group: AID_SYSTEM
caps: 0
