# havoc_device_m30sdd
havoc device Tree of M30s
